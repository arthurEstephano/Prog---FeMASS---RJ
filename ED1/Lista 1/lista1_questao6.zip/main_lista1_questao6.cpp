#include <stdio.h> 
#include <stdlib.h>
#include "lista1_questao6.h"


int main() 
{
	cadastrolivro();
	system("pause");
}
