void codigo_decimal();
