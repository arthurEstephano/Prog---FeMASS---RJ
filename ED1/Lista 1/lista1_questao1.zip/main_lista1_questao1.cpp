#include <iostream>
#include <conio.h> 
#include <stdio.h> 
#include "lista1_questao1.h"

int main(void) 
{
	codigo_decimal();
	return 0;
}
