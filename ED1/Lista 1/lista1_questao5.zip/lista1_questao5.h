typedef struct cadastro Cadastro;
int registro(Cadastro* c);
Cadastro* cria_cadastro (void);
