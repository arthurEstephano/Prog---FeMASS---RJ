#include <stdio.h> 
#include <stdlib.h>
#include "lista1_questao7.h"

int main() 
{
	Cadastro* C;
	C = cria_cadastro();
	registro(C);
}
