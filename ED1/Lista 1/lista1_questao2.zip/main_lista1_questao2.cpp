#include <stdlib.h>
#include <stdio.h> 
#include "lista1_questao2.h"

int main() 

{
	vetor();
}
