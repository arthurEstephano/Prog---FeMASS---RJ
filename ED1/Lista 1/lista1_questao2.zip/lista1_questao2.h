int vetor();
